using System.Collections.Generic;
using Itmo.ObjectOrientedProgramming.Lab1.Expedition;
using Itmo.ObjectOrientedProgramming.Lab1.Ships;
using Itmo.ObjectOrientedProgramming.Lab1.Space;
using Itmo.ObjectOrientedProgramming.Lab1.Space.Obstacles;
using Xunit;

namespace Itmo.ObjectOrientedProgramming.Lab1.Tests;

public class ShipTests
{
    public static IEnumerable<object[]> FirstTest =>
        new List<object[]>
        {
            new object[] { new MySpace(new FogSpace(100)), Spaceship.PleasureShuttle(100), MyExpedition.SecondResult() },
            new object[] { new MySpace(new FogSpace(100)), Spaceship.Avgur(5, 5, false), MyExpedition.SecondResult() },
        };
    public static IEnumerable<object[]> SecondTest =>
        new List<object[]>
        {
            new object[] { new MySpace(new FogSpace(100, FogObstacle.AntimatterFlares())), Spaceship.Vaklas(10000, 10000, false), MyExpedition.FourthResult() },
            new object[] { new MySpace(new FogSpace(100, FogObstacle.AntimatterFlares())), Spaceship.Vaklas(10000, 10000, true), MyExpedition.FirstResult(10000, 10000) },
        };
    public static IEnumerable<object[]> ThirdTest =>
        new List<object[]>
        {
            new object[] { new MySpace(new NitrineSpace(100, CosmoWhale.AntimatterFlares())), Spaceship.Vaklas(10000, 10000, false), MyExpedition.ThirdResult() },
            new object[] { new MySpace(new NitrineSpace(100, CosmoWhale.AntimatterFlares())), Spaceship.Avgur(10000, 10000, false), MyExpedition.FirstResult(37, 37) },
            new object[] { new MySpace(new NitrineSpace(100, CosmoWhale.AntimatterFlares())), Spaceship.Meridian(10000, false), MyExpedition.FirstResult(37, 37) },
        };

    [Theory]
    [MemberData(nameof(FirstTest))]
    public void FirstCase(MySpace space, Spaceship spaceship, string expected)
    {
        int fuel = -1;
        string result = MyExpedition.ExpeditionSimulation(spaceship, space, ref fuel);
        Assert.Equal(expected, result);
    }

    [Theory]
    [MemberData(nameof(SecondTest))]
    public void SecondCase(MySpace space, Spaceship spaceship, string expected)
    {
        int fuel = -1;
        string result = MyExpedition.ExpeditionSimulation(spaceship, space, ref fuel);
        Assert.Equal(expected, result);
    }

    [Theory]
    [MemberData(nameof(ThirdTest))]
    public void ThirdCase(MySpace space, Spaceship spaceship, string expected)
    {
        int fuel = -1;
        string result = MyExpedition.ExpeditionSimulation(spaceship, space, ref fuel);
        Assert.Equal(expected, result);
    }

    [Fact]
    public void FourthCase()
    {
        var space = new MySpace(new DefaultSpace(10));
        Assert.Equal(1, MyExpedition.BestOf(space, Spaceship.PleasureShuttle(100), Spaceship.Vaklas(100, 100, false)));
    }

    [Fact]
    public void FifthCase()
    {
        var space = new MySpace(new FogSpace(100));
        Assert.Equal(2, MyExpedition.BestOf(space, Spaceship.Avgur(99, 99, false), Spaceship.Stella(10000, 10000, false)));
    }

    [Fact]
    public void SixthCase()
    {
        var space = new MySpace(new NitrineSpace(100));
        Assert.Equal(2, MyExpedition.BestOf(space, Spaceship.PleasureShuttle(1000), Spaceship.Vaklas(1000, 1000, false)));
    }

    [Fact]
    public void SeventhCase()
    {
        var space = new MySpace(new NitrineSpace(100, CosmoWhale.AntimatterFlares()), new NitrineSpace(100, CosmoWhale.AntimatterFlares()), new NitrineSpace(100, CosmoWhale.AntimatterFlares()));
        var ship = Spaceship.Meridian(10000, false);
        int fuel = -1;
        Assert.Equal(MyExpedition.FirstResult(1818, 1818), MyExpedition.ExpeditionSimulation(ship, space, ref fuel));
    }
}