using Itmo.ObjectOrientedProgramming.Lab4.Commands;
using Itmo.ObjectOrientedProgramming.Lab4.Parser;
using Xunit;

namespace Itmo.ObjectOrientedProgramming.Lab4.Tests;

public class SystemTests
{
    [Fact]
    public void CorrectCommandParseTest()
    {
        Assert.IsType<ConnectCommand>(CommandParser.Parse("connect myDirectory -m local"));
        Assert.IsType<DisconnectCommand>(CommandParser.Parse("disconnect"));
        Assert.IsType<GotoCommand>(CommandParser.Parse("tree goto C:/Desktop/myDirectory"));
        Assert.IsType<CatCommand>(CommandParser.Parse("file show C:/Desktop/myDirectory/file.txt -m console"));
    }
}