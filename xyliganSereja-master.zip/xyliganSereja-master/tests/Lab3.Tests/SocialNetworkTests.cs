using System;
using Itmo.ObjectOrientedProgramming.Lab3.Exceptions;
using Itmo.ObjectOrientedProgramming.Lab3.Messages;
using Itmo.ObjectOrientedProgramming.Lab3.Messengers;
using Itmo.ObjectOrientedProgramming.Lab3.Proxy;
using Itmo.ObjectOrientedProgramming.Lab3.Users;
using Xunit;

namespace Itmo.ObjectOrientedProgramming.Lab3.Tests;

public class SocialNetworkTests
{
    [Fact]
    public void ReceivesMessagesSavesInUnreadStatus()
    {
        var user = new User();
        var message = new Message("Vspomnil", "Geometriya", 1);
        user.ReceiveMessage(message);
        Assert.False(user.MessageWasRead(0));
    }

    [Fact]
    public void UserMustBeAbleToReadMessages()
    {
        var user = new User();
        var message = new Message("Vspomnil", "Geometriya", 1);
        user.ReceiveMessage(message);
        user.Read(0);
        Assert.True(user.MessageWasRead(0));
    }

    [Fact]
    public void UserShouldNotBeAbleToReadSameMessageTwiceThrows()
    {
        var user = new User();
        var message = new Message("Vspomnil", "Geometriya", 1);
        user.ReceiveMessage(message);
        user.Read(0);
        Assert.Throws<ReadMessageException>(() => user.Read(0));
    }

    [Fact]
    public void MessagesThatNotRelevantInImportanceIgnored()
    {
        var proxy = new MessagePriorityProxy(1);
        var message = new Message("Vspomnil", "Geometriya", 2);
        proxy.Receive(message);
        Assert.Equal("0", proxy.Logger.GetInfo());
    }

    [Fact]
    public void TimeLog()
    {
        var messenger = new ConsoleMessenger();
        var message = new Message("Vspomnil", "Geometriya", 1);
        messenger.AddMessage(message);
        messenger.Print();
        Assert.Equal(DateTime.Today.ToLongDateString(), messenger.Logger.GetInfo());
    }

    [Fact]
    public void ConsoleLog()
    {
        var messenger = new ConsoleMessenger();
        var message = new Message("Vspomnil", "Geometriya", 1);
        messenger.AddMessage(message);
        messenger.Print();
        Assert.NotNull(messenger.Logger.ConsoleLog);
        string expected = $"{DateTime.Today.ToLongDateString()}\nVspomnil\nGeometriya";
        string actual = messenger.Logger.ConsoleLog;
        Assert.Equal(expected, actual);
    }
}
