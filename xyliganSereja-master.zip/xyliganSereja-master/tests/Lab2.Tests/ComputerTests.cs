using Itmo.ObjectOrientedProgramming.Lab2.Builder;
using Xunit;

namespace Itmo.ObjectOrientedProgramming.Lab2.Tests;

public class ComputerTests
{
    [Fact]
    public void FirstCase()
    {
        var computer = new PersonalComputer();
        computer.AddMother("Mother_v1");
        computer.AddCpu("Cpu_v1");
        computer.AddRam("Ram_v1");
        computer.AddSsd("Ssd_v1");
        computer.AddCoolerSystem("Cooler_v1");
        computer.AddXmp("Xmp_v1");
        computer.AddPowerUnit("PowerUnit_v1");
        computer.AddWifiAdapter("5G");
        computer.AddBox("Box_v1");
        BuildResult result = computer.Build();
        Assert.IsType<BuildResult.Success>(result);
    }

    [Fact]
    public void SecondCase()
    {
        var computer = new PersonalComputer();
        computer.AddMother("Mother_v1");
        computer.AddCpu("Cpu_v2");
        computer.AddRam("Ram_v1");
        computer.AddSsd("Ssd_v1");
        computer.AddCoolerSystem("Cooler_v1");
        computer.AddXmp("Xmp_v1");
        computer.AddPowerUnit("PowerUnit_v1");
        computer.AddWifiAdapter("5G");
        computer.AddBox("Box_v1");
        BuildResult result = computer.Build();
        Assert.IsType<BuildResult.WithoutGuarantees>(result);
    }

    [Fact]
    public void ThirdCase()
    {
        var computer = new PersonalComputer();
        computer.AddMother("Mother_v1");
        computer.AddCpu("Cpu_v1");
        computer.AddRam("Ram_v1");
        computer.AddSsd("Ssd_v1");
        computer.AddCoolerSystem("Cooler_v2");
        computer.AddXmp("Xmp_v1");
        computer.AddPowerUnit("PowerUnit_v1");
        computer.AddWifiAdapter("5G");
        computer.AddBox("Box_v1");
        BuildResult result = computer.Build();
        Assert.IsType<BuildResult.Failure>(result);
    }

    [Fact]
    public void FourthCase()
    {
        var computer = new PersonalComputer();
        computer.AddMother("Mother_v1");
        computer.AddRam("Ram_v1");
        computer.AddSsd("Ssd_v1");
        computer.AddCoolerSystem("Cooler_v2");
        computer.AddXmp("Xmp_v1");
        computer.AddPowerUnit("PowerUnit_v1");
        computer.AddWifiAdapter("5G");
        computer.AddBox("Box_v1");
        BuildResult result = computer.Build();
        Assert.IsType<BuildResult.Failure>(result);
    }
}