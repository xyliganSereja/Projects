using Xunit;

namespace Itmo.ObjectOrientedProgramming.Lab5.Tests;

public class BankTest
{
    [Fact]
    public void DataBaseTest()
    {
    }
}