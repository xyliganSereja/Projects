namespace Itmo.ObjectOrientedProgramming.Lab3.Users;

public enum MessagesStatus
{
    Read,
    Unread,
}