namespace Itmo.ObjectOrientedProgramming.Lab3;

public interface IFormattable
{
    string Format();
}