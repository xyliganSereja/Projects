namespace Itmo.ObjectOrientedProgramming.Lab4.Printers;

public interface IPrinter
{
    void Print(string str);
}