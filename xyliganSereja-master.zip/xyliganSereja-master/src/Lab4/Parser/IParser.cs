namespace Itmo.ObjectOrientedProgramming.Lab4.Parser;

public interface IParser
{
    string Parse();
}