namespace Models.Users;

public enum UserRole
{
    Unknown,
    Admin,
    User,
}