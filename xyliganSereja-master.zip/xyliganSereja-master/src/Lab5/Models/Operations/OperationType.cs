namespace Models.Operations;

public enum OperationType
{
    Add,
    Take,
}