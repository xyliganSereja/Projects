namespace Itmo.ObjectOrientedProgramming.Lab1.Expedition;

public enum States
{
    Success,
    LostInSpace,
    DeadCrew,
}