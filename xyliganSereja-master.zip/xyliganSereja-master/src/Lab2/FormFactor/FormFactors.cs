namespace Itmo.ObjectOrientedProgramming.Lab2.FormFactor;

public enum FormFactors
{
    Low,
    Mid,
    Huge,
}